package org.example.function;

public interface ImagesOperations {
	float[] execute(float[] rgb);
}
