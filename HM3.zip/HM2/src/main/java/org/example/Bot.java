package org.example;

import org.example.commands.AppBotCommand;
import org.example.commands.BotCommonCommands;
import org.example.function.FilterOperations;
import org.example.function.ImagesOperations;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.GetFile;
import org.telegram.telegrambots.meta.api.methods.send.SendMediaGroup;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Message;
import org.telegram.telegrambots.meta.api.objects.PhotoSize;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.media.InputMedia;
import org.telegram.telegrambots.meta.api.objects.media.InputMediaPhoto;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.ReplyKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardButton;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.KeyboardRow;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;
import utils.ImageUtils;
import utils.RgbMaster;
import java.io.File;

import java.awt.image.BufferedImage;
import java.io.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.sun.org.apache.xml.internal.serializer.utils.Utils.messages;

public class Bot extends TelegramLongPollingBot {
	HashMap<String, Message> message = new HashMap<>();

	@Override
	public String getBotUsername() {
		return "@TelJava_Bot";
	}

	@Override
	public String getBotToken() {
		return "6620995702:AAF7vra5Akii0ELV76g4652coQSSvqeCV70";
	}

	@Override
	public void onUpdateReceived(Update update) {
		Message message = update.getMessage();
		String chatId = message.getChatId().toString();
		System.out.println(message.getText());
		try{
			SendMessage responseMessage = runCommonCommand(message);
			if(responseMessage != null){
				execute(responseTextMessage);
			}

		}catch (InvocationTargetException | IllegalAccessException | TelegramApiException e){
			throw new RuntimeException(e);
		}
	}
	public void saveImage(String url, String fileName) throws IOException {
		URL urlModel = new URL(url);
		InputStream inputStream = urlModel.openStream();
		OutputStream outputStream = new FileOutputStream(fileName);
		byte[] b = new byte[2048];
        int length;

		while ((length = inputStream.read(b)) != -1) {
		outputStream.write(b,0,length);
		}
		inputStream.close();
		outputStream.close();
	}
	public void processingImage(String fileName, ImagesOperations operation)throws Exception{
		final BufferedImage image = ImageUtils.getImage(fileName);
		final RgbMaster rgbMaster = new RgbMaster(image);
		rgbMaster.changeImage(operation);
		ImageUtils.saveImage(rgbMaster.getImage(), fileName);

	}
	public SendMediaGroup preparePhotoMessage(List<String> localPath, ImagesOperations operation, String chatId) throws Exception{
		SendMediaGroup mediaGroup = new SendMediaGroup();
		ArrayList<InputMedia> medias = new ArrayList<>();
		for (String path : localPath){
			InputMedia inputMedia = new InputMediaPhoto();
			processingImage(path, operation);
			inputMedia.setMedia(new File(path), "path");
			medias.add(inputMedia);
		}
		mediaGroup.setMedias(medias);
		mediaGroup.setChatId(chatId);
		return mediaGroup;
	}
	private List<File> getFilesByMessage(Message message){
		List<PhotoSize> photoSizes = message.getPhoto();
		ArrayList<File> files = new ArrayList<>();
		for (PhotoSize photoSize : photoSizes){
			final String fileId = photoSize.getFileId();
			try{
				files.add(sendApiMethod(new GetFile(fileId)));
			} catch (TelegramApiException e) {
			e.printStackTrace();
			}
		}
		return files;
	}
	private ReplyKeyboardMarkup getKeyboard(){
		ReplyKeyboardMarkup replyKeyboardMarkup = new ReplyKeyboardMarkup();
		ArrayList<KeyboardRow> allKeyboardRows = new ArrayList<>();
		allKeyboardRows.addAll(getKeyboardRows(BotCommonCommands.class));
		allKeyboardRows.addAll(getKeyboardRows(FilterOperations.class));

		replyKeyboardMarkup.setKeyboard(allKeyboardRows);
		replyKeyboardMarkup.setOneTimeKeyboard(true);
		return replyKeyboardMarkup;
	}
	private static ArrayList<KeyboardRow> getKeyboardRows(Class SomeClass){
		Method[] classMethods = SomeClass.getDeclaredMethods();
		ArrayList<AppBotCommand> commands = new ArrayList<>();
		for(Method method : classMethods){
			if(method.isAnnotationPresent(AppBotCommand.class)){
				commands.add(method.getAnnotation(AppBotCommand.class));
			}
		}
		ArrayList<KeyboardRow> keyboardRows = new ArrayList<>();
		int columnCount = 3;
		int rowCount = commands.size() / columnCount + ((commands.size() % columnCount = 0) ? 0 : 1);
		for (int rowIndex = 0; rowIndex < rowCount; rowIndex++) {
			KeyboardRow row = new KeyboardRow();
			for(int columnIndex = 0; columnIndex < columnCount; columnIndex++){
				int Index = rowIndex * columnCount + columnIndex;
				if(Index >= commands.size()) continue;
				AppBotCommand command = commands.get(rowIndex * columnCount + columnIndex);
				KeyboardButton keyboardButton = new KeyboardButton(command.name());
				row.add(keyboardButton);
			}
			keyboardRows.add(row);
		}
		return keyboardRows;
	}
	private String runCommand(String text)throws InvocationTargetException, IllegalAccessException {
		BotCommonCommands commands = new BotCommonCommands();
		Method[] classMethods = commands.getClass().getMethods();
		for (Method method : classMethods){
			if(method.isAnnotationPresent(AppBotCommand.class)){
				AppBotCommand command = method.getAnnotations(AppBotCommand.class);
				if(command.name().equals(text)) {
					method.setAccessible(true);
					return (String) method.invoke(commands);
				}
			}
		}
		return null;
	}
	private SendMessage runCommand(Message message)throws InvocationTargetException, IllegalAccessException{
		String text = message.getText();
		BotCommonCommands commands = new BotCommonCommands();
		Method[] classMethods = commands.getClass().getMethods();
		for (Method method : classMethods){
			if(method.isAnnotationPresent(AppBotCommand.class)){
				AppBotCommand command = method.getAnnotation(AppBotCommand.class);
				if(command.name().equals(text)){
					method.setAccessible(true);
					String responseText = (String) method.invoke(command);
					if(responseText != null){
						SendMessage sendMessage = new SendMessage();
						sendMessage.setChatId(sendMessage.getChatId());
						sendMessage.setText(responseText);
						return sendMessage;
					}
				}
			}
		}
		return null;
	}
	private SendMessage runPhotoMessage(Message message){
		List<File> files = getFilesByMessage(message);
		if(files.isEmpty()) return null;
		String chatId =  message.getChatId().toString();
		messages.put(chatId, message);
		ReplyKeyboardMarkup replyKeyboardMarkup = new ReplyKeyboardMarkup();
		ArrayList<KeyboardRow> allKeyboardRows = new ArrayList<>(getKeyboardRows(FilterOperations.class));
		replyKeyboardMarkup.setKeyboard(allKeyboardRows);
		replyKeyboardMarkup.setOneTimeKeyboard(true);
		SendMessage sendMessage = new SendMessage();
		sendMessage.setChatId(chatId);
		sendMessage.setText("Choose a filter you'd like to apply to the photo");
		return sendMessage;
	}
}



