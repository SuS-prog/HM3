package org.example.commands;

public class BotCommonCommands {
	@AppBotCommand(name = "/hello", description = "when request hello", showInHelp = true)
	String hello(){
		return "Hello, mate. Long time no see!";
	}
	@AppBotCommand(name = "/bye", description = "when request bye", showInHelp = true)
	String bye(){
		return "Are you leaving now? That's so sad, come back ASAP!";
	}
	@AppBotCommand(name = "/help", description = "when request help", showInKeyboard = true)
	String help(){
		return "You used the /help command. Soon in this unit there gonna be all allowed bot commands.";
	}
}
